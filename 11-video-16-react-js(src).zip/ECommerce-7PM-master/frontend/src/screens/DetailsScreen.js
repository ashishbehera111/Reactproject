//receive the id from HomeScreen
//send the id to the DetailsAction

import React from "react";

function DetailsScreen(){
    return(
        <React.Fragment></React.Fragment>
    )
}

export default DetailsScreen;