export const HIT_SERVER = "HIT_SERVER";
export const CATCH_PRODUCTS = "CATCH_PRODUCTS";
export const CATCH_ERROR = "CATCH_ERROR";