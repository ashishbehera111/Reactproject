import React from "react";

function HomeScreen(){
    return(
        <React.Fragment>
            Hello......!
        </React.Fragment>
    )
}

export default HomeScreen;