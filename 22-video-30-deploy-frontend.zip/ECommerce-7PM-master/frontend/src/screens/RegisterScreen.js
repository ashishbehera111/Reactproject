import React from "react";
function RegisterScreen(){
    return(
        <React.Fragment>
            <h1>Registration Soon....!</h1>
        </React.Fragment>
    )
}
export default RegisterScreen;