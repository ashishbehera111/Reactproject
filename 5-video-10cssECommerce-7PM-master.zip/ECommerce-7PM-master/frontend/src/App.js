import logo from './logo.svg';
import './App.css';
import React from 'react';
import HomeScreen from './screens/HomeScreen';

function App() {
  return (
    <React.Fragment>
        <HomeScreen></HomeScreen>
    </React.Fragment>
  );
}

export default App;
